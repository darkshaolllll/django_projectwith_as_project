package com.example.myapplication

import android.app.Activity
import android.view.KeyEvent
import android.view.View
import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.widget.Button
import androidx.compose.runtime.MutableState

class remotemonitor @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
    private val onFakeShutDown: () -> Unit,
    private val onWakeUpScreen: () -> Unit,
    private val currentScreen: MutableState<String>
) : View(context, attrs, defStyleAttr) {

    private var isScreenOff = false

    fun fakeShutDown() {
        isScreenOff = true
        println("进入假关机模式")
        Log.d("RemoteMonitor", "进入假关机模式")
        onFakeShutDown()
    }

    fun wakeUpScreen() {
        isScreenOff = false
        println("退出假关机模式")
        Log.d("RemoteMonitor", "退出假关机模式")
        onWakeUpScreen()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (isScreenOff && event.keyCode != KeyEvent.KEYCODE_POWER) {
            // 假关机状态下拦截所有按键事件，除了电源键
            println("假关机状态，按键无效：${event.keyCode}")
            Log.d("RemoteMonitor", "假关机状态，按键无效：${event.keyCode}")
            return true
        } else if (event.keyCode == KeyEvent.KEYCODE_BACK && currentScreen.value == "display") {
            // 当当前屏幕为 mainscreen 时，不执行返回键操作
            println("当前屏幕是 mainscreen，返回键无效")
            Log.d("RemoteMonitor", "当前屏幕是 mainscreen，返回键无效")
            return true
        } else {
            return super.dispatchKeyEvent(event)
        }
    }
}


