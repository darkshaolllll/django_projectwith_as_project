package com.example.myapplication
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone



@Composable
fun DateTimeDisplay() {
    val currentDateTime = remember { mutableStateOf(getCurrentDateTime()) }

    // 定时更新时间
    LaunchedEffect(Unit) {
        while (true) {
            currentDateTime.value = getCurrentDateTime()
            delay(1000L) // 每秒更新一次
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(100.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center // 垂直居中对齐
        ) {
            // Display the time
            Text(
                text = currentDateTime.value.split(" ")[1], // 提取时间部分
                color = Color.White,
                fontSize = 100.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth(), // 确保文本填满父布局的宽度
                textAlign = TextAlign.Center // 确保文本居中对齐
            )
            Text(
                text = currentDateTime.value.split(" ")[0], // 提取日期部分
                color = Color.White,
                fontSize = 50.sp,
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth(), // 确保文本填满父布局的宽度
                textAlign = TextAlign.Center // 确保文本居中对齐
            )
        }
    }
}

fun getCurrentDateTime(): String {
    val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
    sdf.timeZone = TimeZone.getTimeZone("Asia/Shanghai") // 设置时区为中国上海
    return sdf.format(Date())
}



