package com.example.myapplication
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.myapplication.utils.AppInfo
import com.example.myapplication.utils.getAppName
import com.example.myapplication.utils.getInstalledApps



@Composable
fun mainscreen(navController: NavController) {
    // 加载背景图像
    val backgroundImage = painterResource(id = R.drawable.background)
    val context = LocalContext.current
    val list_of_app: List<AppInfo> = getInstalledApps(context)


    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // 背景图像
        Image(
            painter = backgroundImage,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        DateTimeDisplay()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            LazyRow(
                modifier = Modifier
                    .width(600.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                items(list_of_app.size+1) { item ->
                    var isFocused by remember { mutableStateOf(false) }
                    Box(
                        modifier = Modifier
                            .size(150.dp)
                            .onFocusChanged { focusState ->
                                isFocused = focusState.isFocused
                            }
                            .background(
                                color = if (isFocused) Color(0xa7ccd5).copy(alpha = 0.5f) else Color.Transparent,
                                shape = RectangleShape
                            ),
                        contentAlignment = Alignment.Center // 垂直和水平都居中
                    ) {
                        Box(modifier = Modifier
                            .background(
                                color = if (isFocused) Color(0xa7ccd5).copy(alpha = 0.5f) else Color.Transparent, shape = RectangleShape)
                        )
                        Column(
                            modifier = Modifier
                                .aspectRatio(1f)
                                .clickable {
                                    if (item == 1) {
                                        navController.navigate("newScreen") // 导航到 newScreen
                                    }
                                    else{
                                        val launchIntent = context.packageManager.getLaunchIntentForPackage(list_of_app[item].packageName)
                                        launchIntent?.let { context.startActivity(it) }
                                    }
                                },
                            horizontalAlignment = Alignment.CenterHorizontally, // 子项水平居中
                            verticalArrangement = Arrangement.Center // 子项垂直居中
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .size(50.dp),
                                contentAlignment = Alignment.Center
                                )
                            {
                                Text(
                                    text = if (item==1) "工具箱" else getAppName(context,list_of_app[item].packageName),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                )
                            }

                            when(item){
                                1-> {
                                    Image(
                                        contentDescription = null,
                                        painter = painterResource(id = R.drawable.toolbox)
                                    )
                                }
                                else->{
                                    Image(
                                        modifier = Modifier.size(100.dp),
                                        contentDescription = null,
                                        painter = rememberAsyncImagePainter(model = list_of_app[item].icon)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}






