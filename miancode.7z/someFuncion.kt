package com.example.myapplication.utils

import android.app.Activity
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import android.util.Log
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import androidx.work.*
import java.util.concurrent.TimeUnit
import androidx.compose.foundation.Image







//app的启动与安装
//
///
//

//
//
//
fun handleAppLaunchOrDownload(context: Context, packageName: String) {
    Log.d("handleAppLaunchOrDownload", "开始处理应用启动或下载: $packageName")
    if (isAppInstalled(context, packageName)) {
        Log.d("handleAppLaunchOrDownload", "App已安装: $packageName")
        launchApp(context, packageName)
    } else {
        Log.d("handleAppLaunchOrDownload", "App未安装: $packageName")
        requestApkFromServer(context, packageName)
    }
}

fun isAppInstalled(context: Context, packageName: String): Boolean {
    val pm = context.packageManager
    return try {
        pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES)
        Log.d("isAppInstalled", "App已安装: $packageName")
        true
    } catch (e: PackageManager.NameNotFoundException) {
        Log.d("isAppInstalled", "App未安装: $packageName")
        false
    }
}

fun launchApp(context: Context, packageName: String) {
    Log.d("launchApp", "尝试启动App: $packageName")
    val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
    if (launchIntent != null) {
        Log.d("launchApp", "启动App: $packageName")
        context.startActivity(launchIntent)
    } else {
        Log.e("launchApp", "无法启动应用程序: $packageName")
        Toast.makeText(context, "无法启动应用程序", Toast.LENGTH_SHORT).show()
    }
}

fun requestApkFromServer(context: Context, packageName: String) {
    Log.d("requestApkFromServer", "开始请求APK: $packageName")
    val client = OkHttpClient()
    val json = JSONObject().apply {
        put("name", packageName)
    }
    Log.d("requestApkFromServer", "发送请求到服务器: $packageName, 请求数据: $json")

    val requestBody = json.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
    val request = Request.Builder()
        .url("http://10.0.2.2:8000/api/apk/download/")
        .post(requestBody)
        .build()
    Log.d("Request", request.toString())

    client.newCall(request).enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            Log.e("requestApkFromServer", "请求失败", e)
            e.printStackTrace()
            (context as? Activity)?.runOnUiThread {
                Toast.makeText(context, "请求失败: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        override fun onResponse(call: Call, response: Response) {
            response.use {
                Log.d("requestApkFromServer", "收到服务器响应: $response")
                if (response.isSuccessful) {
                    val inputStream = response.body?.byteStream()
                    if (inputStream != null) {
                        Log.d("requestApkFromServer", "接收到APK文件")
                        saveAndInstallApk(
                            context, inputStream,
                            fileName = TODO()
                        )
                    } else {
                        Log.e("requestApkFromServer", "接收APK文件失败: 输入流为空")
                        (context as? Activity)?.runOnUiThread {
                            Toast.makeText(context, "接收APK文件失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    val errorBody = response.body?.string()
                    Log.e("requestApkFromServer", "无法接收APK文件，响应码: ${response.code}, 错误信息: $errorBody")
                    (context as? Activity)?.runOnUiThread {
                        Toast.makeText(context, "无法接收APK文件，响应码: ${response.code}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    })
}








//获取mac
//
///
//

//
//
//
fun get_mac_address(): String {
    val ethCommand = listOf("su", "-c", "cat /sys/class/net/eth0/address")
    val wlanCommand = listOf("su", "-c", "cat /sys/class/net/wlan0/address")

    val ethProcess = ProcessBuilder(ethCommand).redirectErrorStream(true).start()
    val ethExitCode = ethProcess.waitFor()

    if (ethExitCode == 0) {
        val ethOutput = ethProcess.inputStream.bufferedReader().use { it.readText().trim() }
        Log.d(TAG, "Using eth0. MAC Address: $ethOutput")
        return ethOutput
    } else {
        val wlanProcess = ProcessBuilder(wlanCommand).redirectErrorStream(true).start()
        val wlanExitCode = wlanProcess.waitFor()

        if (wlanExitCode == 0) {
            val wlanOutput = wlanProcess.inputStream.bufferedReader().use { it.readText().trim() }
            Log.d(TAG, "Using wlan0. MAC Address: $wlanOutput")
            return wlanOutput
        } else {
            Log.e(TAG, "No valid network interface found.")
            return "No valid network interface found."
        }
    }
}







//  轮询逻辑
//
///
//

//
//
//
fun requestApk(context: Context) {
    Log.d("轮询开始", "与服务器交互")
    val client = OkHttpClient()
    val json = JSONObject().apply {
        put("mac", get_mac_address())
    }
    Log.d("send mac", "发送请求到服务器: ${json.getString("mac")}, 请求数据: $json")

    val requestBody = json.toString().toRequestBody("application/json; charset=utf-8".toMediaTypeOrNull())
    val request = Request.Builder()
        .url("http://10.0.2.2:8000/connection/detail/")
        .post(requestBody)
        .build()
    Log.d("Request", request.toString())

    client.newCall(request).enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            Log.e("requestApkFromServer", "请求失败", e)
            e.printStackTrace()
            (context as? Activity)?.runOnUiThread {
                Toast.makeText(context, "请求失败: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        override fun onResponse(call: Call, response: Response) {
            response.use {
                Log.d("requestApkFromServer", "收到服务器响应: $response")
                if (response.isSuccessful) {
                    val contentDisposition = response.header("Content-Disposition")
                    val fileName = contentDisposition?.substringAfter("filename=")?.trim('"')
                    val inputStream = response.body?.byteStream()
                    if (inputStream != null && fileName != null) {
                        Log.d("requestApkFromServer", "接收到APK文件: $fileName")
                        saveAndInstallApk(context, inputStream, fileName)
                    } else {
                        Log.e("requestApkFromServer", "接收APK文件失败: 输入流或文件名为空")
                        (context as? Activity)?.runOnUiThread {
                            Toast.makeText(context, "接收APK文件失败", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    val errorBody = response.body?.string()
                    Log.e("requestApkFromServer", "无法接收APK文件，响应码: ${response.code}, 错误信息: $errorBody")
                    Log.d("requestApkFromServer", "错误响应内容: $errorBody")
                    (context as? Activity)?.runOnUiThread {
                        Toast.makeText(context, "无法接收APK文件，响应码: ${response.code}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    })
}

fun saveAndInstallApk(context: Context, inputStream: InputStream, fileName: String) {
    Log.d("saveAndInstallApk", "开始保存APK文件")
    try {
        val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
        val outputStream = FileOutputStream(file)
        val buffer = ByteArray(2048)
        var length: Int

        while (inputStream.read(buffer).also { length = it } > 0) {
            outputStream.write(buffer, 0, length)
        }

        outputStream.flush()
        outputStream.close()
        inputStream.close()

        Log.d("saveAndInstallApk", "APK文件保存成功: ${file.absolutePath}")
        installApk(context, file)
    } catch (e: IOException) {
        Log.e("saveAndInstallApk", "保存APK文件失败", e)
        Toast.makeText(context, "保存APK文件失败", Toast.LENGTH_SHORT).show()
    }
}

fun installApk(context: Context, file: File) {
    val apkUri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
    val intent = Intent(Intent.ACTION_VIEW)
    intent.setDataAndType(apkUri, "application/vnd.android.package-archive")
    intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
    Log.d("installApk", "准备安装APK: ${file.absolutePath}")
    context.startActivity(intent)
}

class ApkRequestWorker(context: Context, workerParams: WorkerParameters) : Worker(context, workerParams) {

    override fun doWork(): Result {
        Log.d("ApkRequestWorker", "doWork: 开始请求APK")
        return try {
            requestApk(applicationContext) // 异步调用，不会堵塞主线程
            scheduleNextWork(applicationContext)
            Log.d("ApkRequestWorker", "doWork: 请求APK完成")
            Result.success()
        } catch (e: Exception) {
            Log.e("ApkRequestWorker", "doWork: 请求APK失败", e)
            Result.failure()
        }
    }

    private fun scheduleNextWork(context: Context) {
        val workRequest = OneTimeWorkRequestBuilder<ApkRequestWorker>()
            .setInitialDelay(100, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueue(workRequest)
        Log.d("ApkRequestWorker", "scheduleNextWork: 下次任务已安排")
    }
}

fun startPolling(context: Context) {
    val constraints = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    val workRequest = OneTimeWorkRequestBuilder<ApkRequestWorker>()
        .setConstraints(constraints)
        .setInitialDelay(100, TimeUnit.SECONDS)
        .build()

    WorkManager.getInstance(context).enqueueUniqueWork(
        "ApkRequestWork",
        ExistingWorkPolicy.KEEP,
        workRequest
    )

    Log.d("startPolling", "startPolling: 轮询任务已启动")
}





//ui
//
///
//

//
//
//
fun getInstalledApps(context: Context): List<AppInfo> {
    val pm: PackageManager = context.packageManager
    val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
    val appList = mutableListOf<AppInfo>()

    // 排除的包名列表
    val excludedPackageNames = listOf(
        "cn.lezhi.speedtest_tv",
        "com.hpplay.happyplay.aw.new",
        "com.xiaobaifile.tv",
        context.packageName // 排除应用本身
    )

    for (packageInfo in packages) {
        // 排除系统应用和指定包名
        if (pm.getLaunchIntentForPackage(packageInfo.packageName) != null &&
            (packageInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0 &&
            packageInfo.packageName !in excludedPackageNames) {
            val appName = pm.getApplicationLabel(packageInfo).toString()
            val appIcon = pm.getApplicationIcon(packageInfo)
            val packageName = packageInfo.packageName // 获取包名
            val firstInstallTime = pm.getPackageInfo(packageName, 0).firstInstallTime
            appList.add(AppInfo(appName, packageName, appIcon, firstInstallTime))
        }
    }

    // 按安装时间排序
    appList.sortBy { it.installTime }

    return appList
}


fun getAppName(context: Context, packageName: String): String {
    val pm: PackageManager = context.packageManager
    return try {
        val appInfo = pm.getApplicationInfo(packageName, 0)
        pm.getApplicationLabel(appInfo).toString()
    } catch (e: PackageManager.NameNotFoundException) {
        "未知应用"
    }
}

fun getAppIcon(context: Context, packageName: String): Drawable? {
    return try {
        val pm = context.packageManager
        pm.getApplicationIcon(packageName)
    } catch (e: PackageManager.NameNotFoundException) {
        e.printStackTrace()
        null
    }
}


@Composable
fun AppIconImage(packageName: String) {
    val context = LocalContext.current
    val drawable = getAppIcon(context, packageName)
    val painter: Painter? = (drawable as? BitmapDrawable)?.bitmap?.asImageBitmap()?.let { BitmapPainter(it) }

    painter?.let {
        Image(
            painter = it,
            contentDescription = null,
            modifier = Modifier.size(150.dp)
        )
    }
}




data class AppInfo(
    val name: String,
    val packageName: String, // 新增属性
    val icon: Drawable,
    val installTime: Long,
)

//
///
//
//
//
//
//
//打开指定apk
fun openAppByPackageName(context: Context, packageName: String) {
    val packageManager = context.packageManager
    val intent = packageManager.getLaunchIntentForPackage(packageName)

    if (intent != null) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        Log.d("openAppByPackageName", "打开应用: $packageName")
    } else {
        Toast.makeText(context, "未找到应用: $packageName", Toast.LENGTH_SHORT).show()
        Log.e("openAppByPackageName", "未找到应用: $packageName")
    }
}







