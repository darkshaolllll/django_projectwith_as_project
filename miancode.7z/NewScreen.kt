package com.example.myapplication

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import com.example.myapplication.utils.AppIconImage
import com.example.myapplication.utils.getAppName
import com.example.myapplication.utils.openAppByPackageName

@Composable
fun newscreen(navController: NavController) {
    val backgroundImage = painterResource(id = R.drawable.background)
    val context = LocalContext.current

    // 为每个可聚焦项声明唯一的聚焦状态变量
    var isFocusedItem1 by remember { mutableStateOf(false) }
    var isFocusedItem2 by remember { mutableStateOf(false) }
    var isFocusedItem3 by remember { mutableStateOf(false) }
    var isFocusedItem4 by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Image(
            painter = backgroundImage,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(60.dp),
            verticalArrangement = Arrangement.Center, // 垂直居中
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically // 水平居中
            ) {
                // 第一个Box
                Box(
                    modifier = Modifier
                        .size(250.dp)
                        .padding(30.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .onFocusChanged { focusState ->
                                isFocusedItem1 = focusState.isFocused
                            }
                            .clickable {
                                val intent = Intent(Settings.ACTION_SETTINGS)
                                context.startActivity(intent)
                            }
                            .background(
                                color = if (isFocusedItem1) Color(0xA7CCD5).copy(alpha = 0.5f) else Color.Transparent
                            ),
                        verticalArrangement = Arrangement.Center, // 垂直居中
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .size(50.dp), // 设置 Box 大小
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = getAppName(context, "cn.lezhi.speedtest_tv"),
                                color = Color.White,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                        AppIconImage("cn.lezhi.speedtest_tv")
                    }
                }

                // 第二个Box
                Box(
                    modifier = Modifier
                        .size(250.dp)
                        .padding(30.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .onFocusChanged { focusState ->
                                isFocusedItem2 = focusState.isFocused
                            }
                            .clickable {
                                openAppByPackageName(context, "cn.lezhi.speedtest_tv")
                            }
                            .background(
                                color = if (isFocusedItem2) Color(0xA7CCD5).copy(alpha = 0.5f) else Color.Transparent
                            ),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .size(50.dp), // 设置 Box 大小
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = getAppName(context, "cn.lezhi.speedtest_tv"),
                                color = Color.White,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                        AppIconImage("cn.lezhi.speedtest_tv")
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 第三个Box
                Box(
                    modifier = Modifier
                        .size(250.dp)
                        .padding(30.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .onFocusChanged { focusState ->
                                isFocusedItem3 = focusState.isFocused
                            }
                            .clickable {
                                openAppByPackageName(context, "com.hpplay.happyplay.aw.new")
                            }
                            .background(
                                color = if (isFocusedItem3) Color(0xA7CCD5).copy(alpha = 0.5f) else Color.Transparent
                            ),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .size(50.dp), // 设置 Box 大小
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = getAppName(context, "com.hpplay.happyplay.aw.new"),
                                color = Color.White,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                        AppIconImage("com.hpplay.happyplay.aw.new")
                    }
                }

                // 第四个Box
                Box(
                    modifier = Modifier
                        .size(250.dp)
                        .padding(30.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .onFocusChanged { focusState ->
                                isFocusedItem4 = focusState.isFocused
                            }
                            .clickable {
                                openAppByPackageName(context, "com.xiaobaifile.tv")
                            }
                            .background(
                                color = if (isFocusedItem4) Color(0xA7CCD5).copy(alpha = 0.5f) else Color.Transparent
                            ),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .size(50.dp), // 设置 Box 大小
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = getAppName(context, "com.xiaobaifile.tv"),
                                color = Color.White,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                        AppIconImage("com.xiaobaifile.tv")
                    }
                }
            }
        }
    }
}




